package appiumAssignment;

import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

import io.appium.java_client.TouchAction;

public class TestCase3 extends BaseSet {
	
	@Test
	public void case3() throws InterruptedException  {
	
	Screen_Page page=new Screen_Page();
	TouchAction touch=new TouchAction(BaseSet.driver);
	touch.tap(tapOptions().withElement(element(page.listElement.get(11)))).perform();
	Thread.sleep(2000);
	TouchAction touch1=new TouchAction(driver);
	touch1.tap(tapOptions().withElement(element(page.dateWidgetlistEle.get(6)))).perform();
	Thread.sleep(2000);
	TouchAction touch2=new TouchAction(driver);
	touch2.tap(tapOptions().withElement(element(page.dialoglistEle.get(0)))).perform();
	Thread.sleep(2000);
	page.datePicker.click();
	Thread.sleep(2000);
	DateFormat dateFormat = new SimpleDateFormat("dd");
	 
	 //get current date
	 Date date = new Date();
	 
	 String date1= dateFormat.format(date);	
	 System.out.println(date1);
	 
	 int k=Integer.parseInt(date1);
	 int j=k+1;
	 String val=String.valueOf(j);
	 System.out.println("Value is"+val);
	
	String xpath="//*[@text='" + val + "']"; 
	driver.findElement(By.xpath(xpath)).click();
	System.out.println("touched date " + val);
	Thread.sleep(5000);
	page.dateBtn.click();
	String dateval=page.selectedDateText.getText();
	System.out.println("Date is "+dateval);
	Thread.sleep(2000);
	System.out.println("Test Case 3 Done");
	
	}

}
