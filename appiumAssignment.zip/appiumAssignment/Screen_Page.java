package appiumAssignment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Screen_Page extends BaseSet{
	
	@FindBy(id="android:id/text1")
	public List<MobileElement> listElement;
	
	@FindBy(id="io.appium.android.apis:id/start")
	public MobileElement startButton;
	
	@FindBy(id="io.appium.android.apis:id/chronometer")
	public MobileElement getTimer;
	
	@FindBy(id="io.appium.android.apis:id/stop")
	public MobileElement stopButton;
	
	@FindBy(id="io.appium.android.apis:id/reset")
	public MobileElement resetButton;
	
	@FindBy(id="android:id/text1")
	public List<MobileElement> controllistEle;
	
	@FindBy(id="android:id/text1")
	public List<MobileElement> holoorOldThemelistEle;
	
	@FindBy(id="io.appium.android.apis:id/check2")
	public MobileElement checkbox2;
	
	@FindBy(id="io.appium.android.apis:id/radio2")
	public MobileElement radio2Btn;
	
	@FindBy(id="io.appium.android.apis:id/star")
	public MobileElement starBtn;
	
	@FindBy(id="io.appium.android.apis:id/toggle1")
	public MobileElement toggle1Btn;
	
	@FindBy(id="android:id/text1")
	public List<MobileElement> dateWidgetlistEle;
	
	@FindBy(id="android:id/text1")
	public List<MobileElement> dialoglistEle;
	
	@FindBy(id="io.appium.android.apis:id/pickDate")
	public MobileElement datePicker;
	
	@FindBy(id="android:id/button1")
	public MobileElement dateBtn;
	
	@FindBy(id="io.appium.android.apis:id/dateDisplay")
	public MobileElement selectedDateText;
	
	@FindBy(id="android:id/text1")
	public List<MobileElement> ExpandablelistEle;
	
	@FindBy(id="android:id/text1")
	public List<MobileElement> CustomAdapterlistEle;
	
	@FindBy(className="android.widget.TextView")
	public List<MobileElement> ExpandableNamelistEle;
	
	@FindBy(xpath="//*[@text='People Names']")
	public MobileElement PeopleNames;
	
	
	@FindBy(xpath="//*[@text='Dog Names']")
	public MobileElement dogNames;
	
	@FindBy(xpath="//*[@text='Fish Names']")
	public MobileElement fishNames;
	
	@FindBy(xpath="//*[@text='Cat Names']")
	public MobileElement catNames;
	
	@FindBy(xpath="//*[@text='Views']")
	public MobileElement views;
	
	@FindBy(xpath="//*[@text='Tabs']")
	public MobileElement tab;
	
	@FindBy(xpath="//*[@text='2. Content By Factory']")
	public MobileElement contentByFactory;
	
	@FindBy(xpath="//*[@text='Tab1']")
	public MobileElement tab1;
	
	@FindBy(xpath="//*[@text='Tab2']")
	public MobileElement tab2;
	
	@FindBy(xpath="//*[@text='Tab3']")
	public MobileElement tab3;
	
	public Screen_Page() {
		PageFactory.initElements(new AppiumFieldDecorator(driver),this);
	}
}
