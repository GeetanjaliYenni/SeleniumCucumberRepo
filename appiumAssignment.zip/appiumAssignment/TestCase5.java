package appiumAssignment;

import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static io.appium.java_client.touch.WaitOptions.waitOptions;
import static io.appium.java_client.touch.offset.PointOption.point;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Dimension;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class TestCase5 extends BaseSet {
	
	@Test
	public void case4() throws InterruptedException  {
	
	Screen_Page page=new Screen_Page();
	TouchAction touch=new TouchAction(BaseSet.driver);
	touch.tap(tapOptions().withElement(element((MobileElement)page.views))).perform();
	
	Boolean tabsIsVisible = false;
	while(tabsIsVisible == false) {
		for(MobileElement items : page.listElement){
		
			if(items.getAttribute("text").equals("Tabs")) {
				touch.tap(tapOptions().withElement(element((MobileElement)page.tab))).perform();
				tabsIsVisible = true;
				break;
			}
		}			
		if(tabsIsVisible == false)
		{				
			Dimension windowSize = driver.manage().window().getSize();				
			touch.press(point(windowSize.width-50,windowSize.height-50)) .waitAction(waitOptions(Duration.ofSeconds(2)))
			  .moveTo(point(windowSize.width-50, windowSize.height-(windowSize.height-200)))
		      .release()
		      .perform();
		}
		else
		{
			break;
		}
	}
	touch.tap(tapOptions().withElement(element((MobileElement)page.contentByFactory))).perform();
	
	for(MobileElement tab : page.ExpandableNamelistEle)
	{
		if(tab.getAttribute("text").equals("TAB1"))
		{
			touch.tap(tapOptions().withElement(element(tab))).perform();
			List<MobileElement> texts=(List<MobileElement>)page.ExpandableNamelistEle;
			String value = texts.get(texts.size()-1).getAttribute("text");
			System.out.println("Value in Tab1 is  " + value);
		}
		if(tab.getAttribute("text").equals("TAB2"))
		{
			touch.tap(tapOptions().withElement(element(tab))).perform();
			List<MobileElement> texts=(List<MobileElement>)page.ExpandableNamelistEle;
			String value = texts.get(texts.size()-1).getAttribute("text");
			System.out.println("Value in Tab2 is  " + value);
		}
		if(tab.getAttribute("text").equals("TAB3"))
		{
			touch.tap(tapOptions().withElement(element(tab))).perform();
			List<MobileElement> texts=(List<MobileElement>)page.ExpandableNamelistEle;
			String value = texts.get(texts.size()-1).getAttribute("text");
			System.out.println("Value in Tab3 is  " + value);
			break;
		}
		
		
	}	
	
	System.out.println("Test Case 5 done");
	driver.quit();
	
	
}
}
