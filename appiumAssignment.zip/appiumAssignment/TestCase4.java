package appiumAssignment;

import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;

import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class TestCase4 extends BaseSet {
	
	@Test
	public void case4() throws InterruptedException  {
	
	Screen_Page page=new Screen_Page();
	TouchAction touch=new TouchAction(BaseSet.driver);
	touch.tap(tapOptions().withElement(element(page.listElement.get(11)))).perform();
	Thread.sleep(2000);
	TouchAction touch1=new TouchAction(driver);
	touch1.tap(tapOptions().withElement(element(page.ExpandablelistEle.get(8)))).perform();
	System.out.println("Done Expandable List");
	TouchAction touch2=new TouchAction(driver);
	touch2.tap(tapOptions().withElement(element(page.CustomAdapterlistEle.get(0)))).perform();
	System.out.println("done Custom Adapter");
	
	for(MobileElement eachElement: page.ExpandablelistEle) {
		System.out.println(eachElement.getAttribute("text"));
	}
	
	TouchAction touch3=new TouchAction(driver);
	String peopleNamesXPATH = "//*[@text='People Names']";
	String dogNamesXPATH = "//*[@text='Dog Names']";
	String catNamesXPATH = "//*[@text='Cat Names']";
	String fishNamesXPATH = "//*[@text='Fish Names']";
	
	touch3.tap(tapOptions().withElement(element((MobileElement)page.PeopleNames))).perform();	
	
	for(MobileElement peopleNames : page.ExpandablelistEle) {
		if(peopleNames.getAttribute("text").equals("Arnold"))
			System.out.println("Arnold verified");
		if(peopleNames.getAttribute("text").equals("Barry"))
			System.out.println("Barry verified");
		if(peopleNames.getAttribute("text").equals("Chuck"))
			System.out.println("Chuck verified");
		if(peopleNames.getAttribute("text").equals("David"))
			System.out.println("David verified");
	}
	
	touch3.tap(tapOptions().withElement(element((MobileElement)page.PeopleNames))).perform();
	
	touch3.tap(tapOptions().withElement(element((MobileElement)page.dogNames))).perform();	
	
	
	for(MobileElement dogNames : page.ExpandablelistEle) {
		if(dogNames.getAttribute("text").equals("Ace"))
			System.out.println("Ace verified");
		if(dogNames.getAttribute("text").equals("Bandit"))
			System.out.println("Bandit verified");
		if(dogNames.getAttribute("text").equals("Cha-Cha"))
			System.out.println("Cha-Cha verified");
		if(dogNames.getAttribute("text").equals("Deuce"))
			System.out.println("Deuce verified");
	}
	
	touch3.tap(tapOptions().withElement(element((MobileElement)page.dogNames))).perform();		
	
	touch3.tap(tapOptions().withElement(element((MobileElement)page.catNames))).perform();	
	
	
	for(MobileElement catNames : page.ExpandablelistEle) {
		if(catNames.getAttribute("text").equals("Fluffy"))
			System.out.println("Fluffy  verified");
		if(catNames.getAttribute("text").equals("Snuggles"))
			System.out.println("Snuggles verified");
	}
	
	touch3.tap(tapOptions().withElement(element((MobileElement)page.catNames))).perform();	
	
	
	touch3.tap(tapOptions().withElement(element((MobileElement)page.fishNames))).perform();	
	
	
	for(MobileElement fishNames : page.ExpandablelistEle) {
		if(fishNames.getAttribute("text").equals("Goldy"))
			System.out.println("Goldy verified");
		if(fishNames.getAttribute("text").equals("Bubbles"))
			System.out.println("Bubbles  verified");
	}
	
	touch3.tap(tapOptions().withElement(element((MobileElement)page.fishNames))).perform();	
	
	System.out.println("Test Case4 Done");
	
	}

}
