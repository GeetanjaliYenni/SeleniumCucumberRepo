package appiumAssignment;

import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;

public class TestCase1 extends BaseSet {
	
@Test
public  void  caseMethod1() throws MalformedURLException, InterruptedException {
	Screen_Page page=new Screen_Page();
	
	TouchAction touch=new TouchAction(BaseSet.driver);
//	List<MobileElement> listElement=(List<MobileElement>)driver.findElementsById("android:id/text1");
	////TAP
	touch.tap(tapOptions().withElement(element(page.listElement.get(11)))).perform();
	Thread.sleep(2000);
	System.out.println("done viewer");
	TouchAction touch1=new TouchAction(BaseSet.driver);
	List<MobileElement> listElement1=(List<MobileElement>)BaseSet.driver.findElementsById("android:id/text1");
	touch1.tap(tapOptions().withElement(element(listElement1.get(3)))).perform();
	page.startButton.click();
	Thread.sleep(2000);
	String timer=page.getTimer.getText();
	System.out.println("Timer is "+timer);
	//BaseSet.driver.findElementById("io.appium.android.apis:id/stop").click();
	//BaseSet.driver.findElement(page.stop).click();
	page.stopButton.click();
	Thread.sleep(2000);
	//BaseSet.driver.findElementById("io.appium.android.apis:id/reset").click();
	//BaseSet.driver.findElement(page.reset).click();
	page.resetButton.click();
	//String timer1=BaseSet.driver.findElementById("io.appium.android.apis:id/chronometer").getText();
	String timer1=page.getTimer.getText();
	System.out.println("reset time is "+timer1);
	Thread.sleep(2000);  
	System.out.println("Test Case1 Done");
			
	    

	}

}
