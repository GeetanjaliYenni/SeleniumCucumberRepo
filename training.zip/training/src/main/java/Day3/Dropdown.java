package Day3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Dropdown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\002F2C744\\Documents\\FSTTraining\\training\\chromedriver.exe");
		//ctrl+shift+o- to import the required class/interface
		WebDriver wd=new ChromeDriver();
		//Navigating to google
		wd.get("https://www.globalsqa.com/demo-site/select-dropdown-menu/");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		WebElement we=wd.findElement(By.tagName("select"));
		Select sel= new Select(we);
		sel.selectByIndex(2);
		sel.selectByValue("ARM");
		sel.selectByVisibleText("Bahamas");
		WebElement we1=wd.findElement(By.tagName("p"));
		Select sel1= new Select(we1);
		sel1.selectByIndex(2);
		
		wd.close();
	}

}
