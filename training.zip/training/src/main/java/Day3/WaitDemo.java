package Day3;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitDemo {
	public static void main(String[] args) throws InterruptedException {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\002F2C744\\Documents\\FSTTraining\\training\\chromedriver.exe");
	// Launching Chrome
			
	WebDriver wd = new ChromeDriver();
	//Implicit
	wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	//PageTimeout
	wd.manage().timeouts().pageLoadTimeout(10, null);
	//Explicit
	WebDriverWait waitExp=new WebDriverWait(wd, 5);
	
waitExp.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("ABC")));
//Fluent Wait
Wait<WebDriver> waitFluent=new FluentWait<WebDriver>(wd)
		.withTimeout(10, TimeUnit.SECONDS)
		.pollingEvery(2,TimeUnit.SECONDS)
		.ignoring(NoSuchElementException.class);
waitFluent.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("ABC")));

	// Navigating to google
	wd.get("https://www.techlistic.com/p/demo-selenium-practice.html");
	wd.manage().window().maximize();
//	Thread.sleep(5000);
	List<WebElement> weColData=wd.findElements(By.xpath("//table[@id='customers']//tr//td"));
	for(int i=0;i<weColData.size();i++) {
		System.out.println(weColData.get(i).getText());
	}
	
	wd.close();
	
}
}

