package Day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckboxAndRadioBtn {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\002F2C744\\Documents\\FSTTraining\\training\\chromedriver.exe");
		//ctrl+shift+o- to import the required class/interface
		WebDriver wd=new ChromeDriver();
		//Navigating to google
		wd.get("https://demos.jquerymobile.com/1.4.5/checkboxradio-radio/");
		wd.manage().window().maximize();
		Thread.sleep(2000);
		List<WebElement> links=wd.findElements(By.xpath("//label[text()='Two']"));
		System.out.println("size "+links.size());
		for(WebElement eachElement:links) 
		{
			System.out.println(eachElement.isSelected());
			eachElement.click();
			System.out.println(eachElement.isSelected());
			
		}

		wd.close();
	}

}
