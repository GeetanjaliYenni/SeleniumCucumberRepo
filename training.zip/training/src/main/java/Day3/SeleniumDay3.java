package Day3;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumDay3 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\002F2C744\\Documents\\FSTTraining\\training\\chromedriver.exe");
		//ctrl+shift+o- to import the required class/interface
		WebDriver wd=new ChromeDriver();
		//Navigating to google
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		//Extracting Navigated URL
		System.out.println("URL: "+wd.getCurrentUrl());
		System.out.println("TITLE: "+wd.getTitle());
		
		
		wd.findElement(By.name("q")).sendKeys("selenium is good"+Keys.ENTER);
		Thread.sleep(2000);
		
		List<WebElement>  listLinks=wd.findElements(By.xpath("//a/h3"));
		for(int i=0;i<listLinks.size();i++) {
			System.out.println(listLinks.get(i).getText());
//			listLinks.get(i).getAttribute("class")
		}
        for(WebElement eachElement:listLinks) {
			System.out.println(eachElement.getText());
//			listLinks.get(i).getAttribute("class")
		}
	
		//Closing Chrome
		wd.close();

	}

}
