package Day1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumLaunch {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//Launching Chrome
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\002F2C744\\Documents\\FSTTraining\\training\\chromedriver.exe");
		//ctrl+shift+o- to import the required class/interface
		WebDriver wd=new ChromeDriver();
		//Navigating to google
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		Thread.sleep(5000);
		//Extracting Navigated URL
		System.out.println("URL: "+wd.getCurrentUrl());
		System.out.println("TITLE: "+wd.getTitle());
		
		/*
		wd.navigate().to("https://in.search.yahoo.com/?fr2=inr");
		System.out.println("title is "+wd.getTitle());
		Thread.sleep(2000);
		wd.navigate().back();
		System.out.println("navigated back :title is "+wd.getTitle());
		Thread.sleep(2000);
		wd.navigate().forward();
		System.out.println("navigated forward :title is "+wd.getTitle());
		wd.navigate().refresh();
		*/
		wd.findElement(By.name("q")).sendKeys("selenium"+Keys.ENTER);
		Thread.sleep(2000);
	//	wd.findElement(By.name("q")).clear();
	//	Thread.sleep(2000);
	//	wd.findElement(By.className("gLFyf gsfi")).sendKeys("selenium");
	//	Thread.sleep(2000);
	//	wd.findElement(By.name("btnK")).click();
	//	Thread.sleep(2000);
		//Closing Chrome
		wd.close();
	}

}
