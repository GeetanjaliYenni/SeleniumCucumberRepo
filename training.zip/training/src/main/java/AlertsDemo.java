import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertsDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\002F2C744\\Documents\\FSTTraining\\training\\chromedriver.exe");
		WebDriver wd = new ChromeDriver();
		// Navigating to google
		wd.get("http://demo.automationtesting.in/Alerts.html");
		Thread.sleep(5000);
		wd.findElement(By.xpath("//*[@class='btn btn-danger']")).click();
		wd.switchTo().alert().accept();
		Thread.sleep(5000);
		wd.findElement(By.partialLinkText("Alert with OK & Cancel")).click();
		wd.findElement(By.xpath("//*[@class='btn btn-primary']")).click();
		wd.switchTo().alert().accept();
		wd.findElement(By.xpath("//*[@class='btn btn-primary']")).click();
		wd.switchTo().alert().dismiss();
		Thread.sleep(5000);
		wd.findElement(By.partialLinkText("Alert with Textbox")).click();
		wd.findElement(By.xpath("//*[@class='btn btn-info']")).click();
		wd.switchTo().alert().sendKeys("test");
		wd.switchTo().alert().accept();
		wd.findElement(By.xpath("//*[@class='btn btn-info']")).click();
		wd.switchTo().alert().accept();
		System.out.println("passed");
		
		wd.close();
	}

}
