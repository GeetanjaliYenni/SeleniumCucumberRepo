package runner;

import org.junit.Test;

public class Runner1 {
	@Test
	public void print()
	{
		System.out.println("runner class");
	}

}
