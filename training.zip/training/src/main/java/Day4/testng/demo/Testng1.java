package Day4.testng.demo;

public class Testng1 {

}
