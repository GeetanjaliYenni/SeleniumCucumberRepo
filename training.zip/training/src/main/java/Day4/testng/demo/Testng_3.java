package Day4.testng.demo;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class Testng_3 {
	@Test(dependsOnMethods="testMethod2")
	public void testMethod1() {
		System.out.println("Inside My Test ng method testMethod 1 ");
	}
	@Parameters({"browser","URL"})
	@Test()
	public void testMethod2(String br,String url) {
		System.out.println("Inside My Test ng method testMethod 2");
		System.out.println("BROWSER="+br);
		System.out.println("URL="+url);
	}

	@Test(priority = 1)
	public void testMethod3() {
		System.out.println("Inside My Test ng method testMethod 3");
	}	

}
