package Day4.testng.demo;

import org.testng.annotations.Test;

public class Testng_2 {
	@Test(dependsOnMethods="testMethod2")
	public void testMethod1() {
		System.out.println("Inside My Test ng method testMethod 1 ");
	}
	@Test()
	public void testMethod2() {
		System.out.println("Inside My Test ng method testMethod 2");
		
	}

	@Test(priority = 1)
	public void testMethod3() {
		System.out.println("Inside My Test ng method testMethod 3");
	}

}
