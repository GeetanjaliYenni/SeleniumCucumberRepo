package Day4.testng.demo;

import org.testng.annotations.Test;

public class MyFirstTestngClass {
	
	@Test
	public void method1() {
		System.out.println("testng method 1");
	}

}
