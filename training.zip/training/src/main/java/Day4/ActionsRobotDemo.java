package Day4;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsRobotDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\002F2C744\\Documents\\FSTTraining\\training\\chromedriver.exe");

		WebDriver wd = new ChromeDriver();
		wd.manage().window().maximize();
		Thread.sleep(2000);
		// Navigating to URL
		wd.get("https://www.google.com/");
		Thread.sleep(2000);
		WebElement inputSerachBox = wd.findElement(By.name("q"));
		Actions action=new  Actions(wd);
		action.keyDown(inputSerachBox,Keys.SHIFT);
		action.sendKeys(inputSerachBox,"SELenium");
		action.keyUp(inputSerachBox,Keys.SHIFT);
		action.build().perform();
		//inputSerachBox.clear();
		Thread.sleep(2000);
        //Double click
		action.doubleClick();
		Thread.sleep(2000);
        //CTRL+C
		//inputSerachBox.clear();
		action.keyDown(inputSerachBox,Keys.CONTROL+"c");
		action.sendKeys(inputSerachBox,"Selenium");
		action.keyUp(inputSerachBox,Keys.CONTROL+"c");
		Thread.sleep(2000);
        
		Thread.sleep(2000);
		//wd.close();
	}

}
