package Day4;

import java.awt.AWTException;
import java.awt.event.KeyEvent;
import java.awt.Robot;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class RobotDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\002F2C744\\Documents\\FSTTraining\\training\\chromedriver.exe");

		WebDriver wd = new ChromeDriver();
		wd.manage().window().maximize();
		Thread.sleep(2000);
		// Navigating to URL
		wd.get("https://www.google.com/");
		Thread.sleep(2000);
		WebElement inputSerachBox = wd.findElement(By.name("q"));
		Actions action=new  Actions(wd);
		action.keyDown(inputSerachBox,Keys.SHIFT);
		action.sendKeys(inputSerachBox,"selenium");
		action.keyUp(inputSerachBox,Keys.SHIFT);
		action.build().perform();
		Thread.sleep(10000);
		
		try {
			Robot rbt = new Robot();
			rbt.keyPress(KeyEvent.VK_6);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Thread.sleep(2000);
		System.out.println("End");
		wd.close();
	}

}
