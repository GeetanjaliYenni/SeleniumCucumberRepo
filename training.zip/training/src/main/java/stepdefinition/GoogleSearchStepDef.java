package stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GoogleSearchStepDef {
	WebDriver wd;
	
	@Given("User launch google website")
	public void user_launch_google_website() throws InterruptedException {
	    System.out.println("launch google site");
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\002F2C744\\Documents\\FSTTraining\\training\\chromedriver.exe");
		wd=new ChromeDriver();
		wd.get("https://www.google.com/");
		wd.manage().window().maximize();
		Thread.sleep(5000);
	}

	@When("User enter text {string}")
	public void user_enter_text(String text) throws InterruptedException {
	   System.out.println("enter text "+ text);
	   wd.findElement(By.name("q")).sendKeys(text);
	   Thread.sleep(2000);
	   wd.findElement(By.name("btnK")).click();
	   Thread.sleep(2000);
	   
	}
	
	@Then("User click first link")
	public void user_click_first_link() {
	    System.out.println("user clicks on link");
	    wd.findElement(By.xpath("(//a//h3)[1]")).click();
	    wd.close();
	    
	}
	@When("User enter text")
	public void User_enter_text() {
	    System.out.println("test");
	}


}
